prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Applie Leave'
,p_alias=>'APPLIE-LEAVE'
,p_step_title=>'Applie Leave'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'AKSHAY.PATIL@ESTUATE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230227114315'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53692497759835861213)
,p_plug_name=>'Leave Details'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53692498187976861217)
,p_plug_name=>'Applie Leave'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P6_REQUEST'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53692498876095861224)
,p_button_sequence=>20
,p_button_name=>'Applie'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Applie'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_REQUEST:SHOW'
,p_icon_css_classes=>'fa-check-square'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53692499199770861227)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_button_name=>'Submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit '
,p_icon_css_classes=>'fa-arrow-circle-up'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53692499276086861228)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_button_name=>'Cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_image_alt=>'Cancel'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_REQUEST:'
,p_icon_css_classes=>'fa-arrow-circle-down'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(53692499674899861232)
,p_branch_name=>'redirect_to_subbmission'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692497818722861214)
,p_name=>'P6_PRIVILAGE_LEAVES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(53692497759835861213)
,p_prompt=>'Privilage Leaves'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692497917776861215)
,p_name=>'P6_SICK_LEAVES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(53692497759835861213)
,p_prompt=>'Sick Leaves'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692498221104861218)
,p_name=>'P6_LEAVE_TYPE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Leave Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Privilage leave;P,Sick Leave;S'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692498385781861219)
,p_name=>'P6_FROM_DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_prompt=>'From Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692498462131861220)
,p_name=>'P6_TO_DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_prompt=>'To Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692498591878861221)
,p_name=>'P6_DIFFERENCE_IN_DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692498605151861222)
,p_name=>'P6_REASON'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_prompt=>'Reason'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692498764382861223)
,p_name=>'P6_LEAVE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select AP1_LEAVE_ID.nextval from dual; '
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53692498936645861225)
,p_name=>'P6_REQUEST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(53692498187976861217)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(53692499500895861231)
,p_validation_name=>'Privilage_leave_validation'
,p_validation_sequence=>10
,p_validation=>':P6_PRIVILAGE_LEAVES >= :P6_DIFFERENCE_IN_DATE;'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Insufficient number of Privilage leaves!! '
,p_always_execute=>'Y'
,p_validation_condition=>'P6_LEAVE_TYPE'
,p_validation_condition2=>'P'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(53692498591878861221)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(53692499769167861233)
,p_validation_name=>'Sick_leave_validation_1'
,p_validation_sequence=>20
,p_validation=>':P6_SICK_LEAVES>=:P6_DIFFERENCE_IN_DATE;'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Insufficient number of Sick leaves!! '
,p_always_execute=>'Y'
,p_validation_condition=>'P6_LEAVE_TYPE'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(53692498591878861221)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53692499369443861229)
,p_name=>'on_change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_TO_DATE'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53692499403353861230)
,p_event_id=>wwv_flow_imp.id(53692499369443861229)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'exequte_pl_sql_code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select',
'     trunc((to_date(:P6_TO_DATE,''mm-dd-yyyy'') - to_date(:P6_FROM_DATE,''mm-dd-yyyy'')+1))',
'    into :P6_DIFFERENCE_IN_DATE from dual;',
'',
'     ',
'end;'))
,p_attribute_02=>'P6_FROM_DATE,P6_TO_DATE'
,p_attribute_03=>'P6_DIFFERENCE_IN_DATE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(53692498038263861216)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'pre_populate_leave_details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select ',
'        PRIVILAGE_LEAVE,',
'        SICK_LEAVE',
'    into',
'        :P6_PRIVILAGE_LEAVES,',
'        :P6_SICK_LEAVES',
'    from ',
'        AP1_LEAVE_DETAILS',
'    where ',
'        EMPLOYEE_ID = :G_USER_ID;',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(53692499066645861226)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'save_leaves_to_table'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    AP1_LEAVE_PROCESS.ap1_leave_details_insert',
'    (',
'        p_leave_id=>:P6_LEAVE_ID,',
'        p_employee_id=>:G_USER_ID,',
'        p_from_date=>:P6_FROM_DATE,',
'        p_to_date=>:P6_TO_DATE,',
'        p_reason=>:P6_REASON,',
'        p_type=>:P6_LEAVE_TYPE',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(53692499199770861227)
);
wwv_flow_imp.component_end;
end;
/
