prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Rise Ticket'
,p_alias=>'RISE-TICKET'
,p_page_mode=>'MODAL'
,p_step_title=>'Rise Ticket'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'AKSHAY.PATIL@ESTUATE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230227041140'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55987455738870054702)
,p_plug_name=>'Rise Ticket'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(41631122246389264812)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(55987457070805054715)
,p_button_sequence=>20
,p_button_name=>'Submit_button'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit '
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(55987457144558054716)
,p_button_sequence=>40
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_image_alt=>'Cancel'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55987455894422054703)
,p_name=>'P12_TICKET_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(55987455738870054702)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select AP1_TICKET_ID_SEQUENCE.nextval from dual;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55987455967612054704)
,p_name=>'P12_TICKET_CATEGORY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(55987455738870054702)
,p_prompt=>'Ticket Category'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select TICKET_CATEGORY_VALUE display, TICKET_CATEGORY_ID  return from AP1_TICKET_CATEGORY'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55987456547274054710)
,p_name=>'P12_TICKET_SUB_CATEGORY'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(55987455738870054702)
,p_prompt=>'Ticket Sub Category'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'TICKET_SUB_CATEGORY_VALUE display,',
'TICKET_SUB_CATEGORY_ID return ',
'from AP1_TICKET_SUB_CATEGORY where TICKET_CATEGORY_ID = :P12_TICKET_CATEGORY',
''))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P12_TICKET_CATEGORY'
,p_ajax_items_to_submit=>'P12_TICKET_SUB_CATEGORY'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55987456633283054711)
,p_name=>'P12_TICKET_ISSUE_REQUEST_TYPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(55987455738870054702)
,p_prompt=>'Ticket Issue Request Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'ISSUE_REQUEST_TYPE_VALUE display,',
'ISSUE_REQUEST_TYPE_ID return',
'from AP1_ISSUE_REQUEST_TYPE where TICKET_SUB_CATEGORY_ID = :P12_TICKET_SUB_CATEGORY'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P12_TICKET_SUB_CATEGORY'
,p_ajax_items_to_submit=>'P12_TICKET_ISSUE_REQUEST_TYPE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55987456728804054712)
,p_name=>'P12_TICKET_ADDITIONAL_INFO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(55987455738870054702)
,p_prompt=>'Ticket Additional Info'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55987456860211054713)
,p_name=>'P12_TICKET_ATTACHMENT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(55987455738870054702)
,p_prompt=>'Ticket Attachment'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55987456962146054714)
,p_name=>'P12_PRIORITY'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(55987455738870054702)
,p_prompt=>'Priority'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:High;A,Low;C,Medium;B'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55987457323090054718)
,p_name=>'P12_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(55987455738870054702)
,p_item_default=>'select sysdate from dual'
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(55987457203268054717)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert_process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_errm varchar2(2000);',
'    l_TICKET_CATEGORY_code varchar2(100);',
'    l_TICKET_SUB_CATEGORY_Code varchar2(100);',
'    l_ISSUE_REQUEST_TYPE_code varchar2(100);',
'    a_filename VARCHAR2(400);',
'    a_mime_type VARCHAR2(255);',
'    a_blob_content BLOB;',
'begin',
'        select TICKET_CATEGORY_CODE into l_TICKET_CATEGORY_code from AP1_TICKET_CATEGORY where TICKET_CATEGORY_ID = :P12_TICKET_CATEGORY;',
'        select TICKET_SUB_CATEGORY_CODE into l_TICKET_SUB_CATEGORY_Code from AP1_TICKET_SUB_CATEGORY where TICKET_SUB_CATEGORY_ID = :P12_TICKET_SUB_CATEGORY;',
'        select ISSUE_REQUEST_TYPE_CODE into l_ISSUE_REQUEST_TYPE_code from AP1_ISSUE_REQUEST_TYPE where ISSUE_REQUEST_TYPE_ID = :P12_TICKET_ISSUE_REQUEST_TYPE;',
'        -- selecting all the value required for the entry of the table ',
'        insert ',
'        into AP1_TICKET_MANAGMENT',
'        (',
'            TICKET_ID,',
'            EMPLOYEE_ID,',
'            TICKET_CATEGORY,',
'            TICKET_CATEGORY_ID,',
'            TICKET_SUB_CATEGORY,',
'            TICKET_SUB_CATEGORY_ID,',
'            TICKET_ISSUE_REQUEST_TYPE,',
'            TICKET_ISSUE_REQUEST_TYPE_ID,',
'            TICKET_PRIORITY,',
'            TICKET_ADDITIONAL_INFO,',
'            TICKET_DATE,',
'            STATUS',
'        )',
'        values',
'        (',
'            :P12_TICKET_ID,',
'            :G_USER_ID,',
'            l_TICKET_CATEGORY_code,',
'            :P12_TICKET_CATEGORY,',
'            l_TICKET_SUB_CATEGORY_Code,',
'            :P12_TICKET_SUB_CATEGORY,',
'            l_ISSUE_REQUEST_TYPE_code,',
'            :P12_TICKET_ISSUE_REQUEST_TYPE,',
'            :P12_PRIORITY,',
'            :P12_TICKET_ADDITIONAL_INFO,',
'            :P12_DATE,',
'            ''Applied''',
'        );',
'',
'        select FILENAME, MIME_TYPE, BLOB_CONTENT  ',
'        into a_filename, a_mime_type, a_blob_content',
'        from apex_application_temp_files  ',
'        where name = :P12_TICKET_ATTACHMENT;',
'  ',
'        UPDATE ',
'        AP1_TICKET_MANAGMENT',
'        SET',
'        TICKET_ATTACHMENT_FILE_NAME = a_filename,',
'        TICKET_ATTACHMENT_MIMI_TYPE = a_mime_type, ',
'        TICKET_ATTACHMENT = a_blob_content',
'        WHERE  TICKET_ID = :P12_TICKET_ID;',
'',
'        exception',
'            when others then ',
'                l_errm := SQLERRM;',
'                insert into AP1_ERROR values (''insert_process.page12'',l_errm);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(55987457070805054715)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(55987457551515054720)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'close_dailgog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
