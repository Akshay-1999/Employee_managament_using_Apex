prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Adding Assets'
,p_alias=>'ADDING-ASSETS'
,p_step_title=>'Adding Assets'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(56533551876466296511)
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'AKSHAY.PATIL@ESTUATE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230224095508'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56095097837352129231)
,p_plug_name=>'Assets Details '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56530980362049765610)
,p_button_sequence=>30
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_image_alt=>'Cancel'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56530980254032765609)
,p_button_sequence=>40
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_condition=>'P16_REQUEST'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56530980746634765614)
,p_button_sequence=>50
,p_button_name=>'Update'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update'
,p_button_condition=>'P16_REQUEST'
,p_button_condition2=>'UPDATE'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(56530981013436765617)
,p_branch_name=>'redirect_to_directory'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098080205129233)
,p_name=>'P16_EMPLOYEE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Employee Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098174703129234)
,p_name=>'P16_ASSESTS_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_item_default=>'select AP1_ASSEST_ID_SEQUENCE.nextval from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Assests Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098291773129235)
,p_name=>'P16_ASSEST_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Assest Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select assest_type display, assest_type return from ap1_assest_type'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098386557129236)
,p_name=>'P16_ASSEST'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Assest'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'Assest display ,Assest return ',
'from ap1_Assest ',
'where assest_type = :P16_ASSEST_TYPE'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P16_ASSEST_TYPE'
,p_ajax_items_to_submit=>'P16_ASSEST'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098450673129237)
,p_name=>'P16_ASSEST_COMPANY'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Assest Company'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098546417129238)
,p_name=>'P16_MODEL_PRODUCT_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Model Product Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098605964129239)
,p_name=>'P16_ASSIGNED_DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Assigned Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098786745129240)
,p_name=>'P16_PRODUCT_KEY'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Product Key'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098889918129241)
,p_name=>'P16_OS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Os'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Windows;Windows,MAC;MAC,Linux;Linux'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095098945026129242)
,p_name=>'P16_MAC_ADDRESS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Mac Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095099007358129243)
,p_name=>'P16_ASSEST_WARRENTY'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'ASSEST_WARRENTY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095099139582129244)
,p_name=>'P16_RETURN_DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_prompt=>'Return Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>'P16_REQUEST'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56530980567754765612)
,p_name=>'P16_REQUEST'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(56095097837352129231)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56530980673805765613)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'pre_populating'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select ',
'        employee_id ,',
'        Assest_type,',
'        Assest  ,',
'        Assest_Company  ,',
'        Model_Product_id  ,',
'        Assigned_date  ,',
'        Product_Key  ,',
'        OS  ,',
'        Mac_Address  ,',
'        Assest_Warrenty ',
'    into',
'        :P16_EMPLOYEE_ID,',
'        :P16_ASSEST_TYPE,',
'        :P16_ASSEST',
'        :P16_ASSEST_COMPANY,',
'        :P16_ASSEST_COMPANY,',
'        :P16_MODEL_PRODUCT_ID,',
'        :P16_ASSIGNED_DATE,',
'        :P16_PRODUCT_KEY,',
'        :P16_OS,',
'        :P16_MAC_ADDRESS,',
'        :P16_ASSEST_WARRENTY',
'    from ap1_employee_assests where assests_id = :P16_ASSESTS_ID;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P16_REQUEST'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'UPDATE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56530980483555765611)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'insert_process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    AP1_ASSEST_PRROCESS.Assest_insert',
'    (',
'            p_assests_id=>:P16_ASSESTS_ID,',
'            p_employee_id=>:P16_EMPLOYEE_ID,',
'            p_Assest_type=>:P16_ASSEST_TYPE,',
'            p_Assest=>:P16_ASSEST,',
'            p_Assest_Company=>:P16_ASSEST_COMPANY,',
'            p_Model_Product_id=>:P16_MODEL_PRODUCT_ID ,',
'            p_Assigned_date=>:P16_ASSIGNED_DATE,',
'            p_Product_Key=>:P16_PRODUCT_KEY ,',
'            p_OS=>:P16_OS ,',
'            p_Mac_Address=>:P16_MAC_ADDRESS,',
'            p_Assest_Warrenty=>:P16_ASSEST_WARRENTY',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56530980254032765609)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56530980837999765615)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    AP1_ASSEST_PRROCESS.Assest_update',
'        (',
'            p_assests_id=>:P16_ASSESTS_ID,',
'            p_employee_id=>:P16_EMPLOYEE_ID,',
'            p_Assest_type=>:P16_ASSEST_TYPE,',
'            p_Assest=>:P16_ASSEST,',
'            p_Assest_Company=>:P16_ASSEST_COMPANY,',
'            p_Model_Product_id=>:P16_MODEL_PRODUCT_ID ,',
'            p_Assigned_date=>:P16_ASSIGNED_DATE,',
'            p_Product_Key=>:P16_PRODUCT_KEY ,',
'            p_OS=>:P16_OS ,',
'            p_Mac_Address=>:P16_MAC_ADDRESS,',
'            p_Assest_Warrenty=>:P16_ASSEST_WARRENTY,',
'            p_return_date=>:P16_RETURN_DATE',
'        );',
'end; '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56530980746634765614)
);
wwv_flow_imp.component_end;
end;
/
