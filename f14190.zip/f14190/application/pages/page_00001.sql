prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Employee Management  Application 1'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-image {',
'  width: 395px;',
'  height: 395px;',
'  border-radius: 50%;',
'  border: 2px solid #dff702;',
'  filter: drop-shadow(0 0 8px #ff5722);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'AKSHAY.PATIL@ESTUATE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230302071138'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41631297940713264905)
,p_plug_name=>'Employee Management  Application 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(41631155235397264827)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(52153858160400436621)
,p_plug_name=>'Profile_pick'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_column=>1
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56530981195637765618)
,p_plug_name=>'Assets'
,p_region_template_options=>'#DEFAULT#:::t-Region--accent6:::t-Region--scrollBody:::::::::'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56530981397005765620)
,p_plug_name=>'assets'
,p_parent_plug_id=>wwv_flow_imp.id(56530981195637765618)
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(41631178422460264838)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    assests_id,',
'    Assest_type,',
'    Assest,',
'    Assest_Company,',
'    Model_Product_id',
' from ap1_employee_assests where employee_id = :g_USER_ID; '))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'assets'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56530981584806765622)
,p_name=>'ASSESTS_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASSESTS_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Assests Id'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>10
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56530981734623765624)
,p_name=>'ASSEST_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASSEST_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Assest Type'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56530981868260765625)
,p_name=>'ASSEST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASSEST'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Assest'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56530981957476765626)
,p_name=>'ASSEST_COMPANY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASSEST_COMPANY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Assest Company'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56530982086434765627)
,p_name=>'MODEL_PRODUCT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MODEL_PRODUCT_ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Model Product Id'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(56530981463619765621)
,p_internal_uid=>56530981463619765621
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(56558337721613755975)
,p_interactive_grid_id=>wwv_flow_imp.id(56530981463619765621)
,p_static_id=>'565583378'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(56558337965470755976)
,p_report_id=>wwv_flow_imp.id(56558337721613755975)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(56558338692187756027)
,p_view_id=>wwv_flow_imp.id(56558337965470755976)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(56530981584806765622)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(56558340770121756120)
,p_view_id=>wwv_flow_imp.id(56558337965470755976)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(56530981734623765624)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(56558341851994756166)
,p_view_id=>wwv_flow_imp.id(56558337965470755976)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(56530981868260765625)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(56558342657767756211)
,p_view_id=>wwv_flow_imp.id(56558337965470755976)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(56530981957476765626)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(56558343601510756257)
,p_view_id=>wwv_flow_imp.id(56558337965470755976)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(56530982086434765627)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83045608649573724069)
,p_plug_name=>'Profile'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83045779631917401205)
,p_plug_name=>'Work Details'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83045808276215403730)
,p_plug_name=>'Personal Details'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(52153858711140436627)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(52153858160400436621)
,p_button_name=>'Uplod_pick'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Uplod Pick'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:10::'
,p_icon_css_classes=>'fa-arrow-circle-up'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43831819277078046324)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(83045808276215403730)
,p_button_name=>'Update'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update'
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789125828603766153)
,p_name=>'P1_REQUEST'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789126292313766153)
,p_name=>'P1_EMPLOYEE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_prompt=>'Employee Id'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789126651106766154)
,p_name=>'P1_FIRST_NAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_prompt=>'First Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789127047493766154)
,p_name=>'P1_LAST_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_prompt=>'Last Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789127403343766154)
,p_name=>'P1_EMAIL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789127824279766154)
,p_name=>'P1_CONTACT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_prompt=>'Contact'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789128269891766155)
,p_name=>'P1_JOINING_DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_prompt=>'Joining Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789128641464766155)
,p_name=>'P1_GENDER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_prompt=>'Gender'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Male;Male,Female;Female'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#:::::::::'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789129042262766155)
,p_name=>'P1_DATE_OF_BIRTH'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(83045608649573724069)
,p_prompt=>'Date Of Birth'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#:::::::::'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789295752649443278)
,p_name=>'P1_PROJECT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(83045779631917401205)
,p_prompt=>'Project'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select project_name display,project_id return from ap1_project;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789296115327443279)
,p_name=>'P1_MANAGER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(83045779631917401205)
,p_prompt=>'Manager'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select EMPLOYEE_NAME display,EMPLOYEE_ID return from AP1_MANAGER;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789296523957443279)
,p_name=>'P1_ROLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(83045779631917401205)
,p_item_default=>'select ROLE_NAME display,role_id return from ap1_roles'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Role'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789324066707445800)
,p_name=>'P1_PERMENANT_ADDRESS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(83045808276215403730)
,p_prompt=>'Permenant Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789324402908445801)
,p_name=>'P1_PERMENANT_PINCODE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(83045808276215403730)
,p_prompt=>'Permenant Pincode'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789324843881445801)
,p_name=>'P1_CURRENT_ADDRESS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(83045808276215403730)
,p_prompt=>'Current Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789325292983445802)
,p_name=>'P1_CURRENT_PINCODE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(83045808276215403730)
,p_prompt=>'Current Pincode'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789325689086445802)
,p_name=>'P1_STATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(83045808276215403730)
,p_prompt=>'State'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select STATE_NAME display ,STATE_NAME return from ap1_state',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41789326058897445802)
,p_name=>'P1_CITY'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(83045808276215403730)
,p_prompt=>'City'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select CITY_NAME display,CITY_NAME return from ap1_city where STATE_NAME = :P1_STATE'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P1_STATE'
,p_ajax_items_to_submit=>'P1_CITY'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52153858567647436625)
,p_name=>'P1_PROFILE_PICTURE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(52153858160400436621)
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>'select PROFILE_PICTURE from AP1_PROFILE_IMAGE where employee_id = :P1_EMPLOYEE_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56095096600995129219)
,p_name=>'P1_ROLL_NAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(83045779631917401205)
,p_prompt=>'Roll Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(41631258536837264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41657104158498956523)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'profile_load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  ',
' begin',
':P1_EMPLOYEE_ID := :G_USER_ID;',
'    select ',
'        FIRST_NAME,',
'        LAST_NAME,',
'        EMAIL,',
'        CONTACT,',
'        GENDER,',
'        JOINING_DATE,',
'        DATE_OF_BIRTH',
'    into',
'        :P1_FIRST_NAME,',
'        :P1_LAST_NAME,',
'        :P1_EMAIL,',
'        :P1_CONTACT,',
'        :P1_GENDER,',
'        :P1_JOINING_DATE,',
'        :P1_DATE_OF_BIRTH',
'    from ap1_employee where employee_id =:P1_EMPLOYEE_ID ;',
'    select ',
'        PERMANENT_ADDRESS,',
'        PERMANENT_PINCODE,',
'        CURRENT_ADDRESS,',
'        CURRENT_PINCODE,',
'        STATE,',
'        CITY',
'    into',
'        :P1_PERMENANT_ADDRESS,',
'        :P1_PERMENANT_PINCODE,',
'        :P1_CURRENT_ADDRESS,',
'        :P1_CURRENT_PINCODE,',
'        :P1_STATE,',
'        :P1_CITY',
'    from AP1_EMPLOYEE_PROFILE where employee_id = :P1_EMPLOYEE_ID;',
'    select ',
'        PROJECT_ID,',
'        MANAGER_ID',
'    into',
'        :P1_PROJECT,',
'        :P1_MANAGER',
'    from AP1_EMP_PRO_MAN where employee_id = :P1_EMPLOYEE_ID;',
'    select',
'        ROLE_ID',
'    into',
'        :P1_ROLE',
'    from AP1_EMP_ROLE where employee_id = :P1_EMPLOYEE_ID; ',
'    select',
'        ROLE_NAME',
'    into',
'        :P1_ROLL_NAME',
'    from AP1_ROLES where ROLE_ID = :P1_ROLE;',
'    /*select ',
'        EMP_PHOTO',
'    into',
'        :P1_PROFILE_PICTURE',
'    from AP1_PROFILE_IMAGE where employee_id = :P1_EMPLOYEE_ID;*/',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47744797763498146126)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_leave_details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_errm varchar2(2000);',
'BEGIN',
'  DBMS_SCHEDULER.create_job (',
'    job_name        => ''example_job1'',',
'    job_type        => ''PLSQL_BLOCK'',',
'    job_action      => ''BEGIN AP1_LEAVE_UPDATE_PROCEDURE; END;'',',
'    start_date      => 	systimestamp,',
'    repeat_interval => ''FREQ=MONTHLY; BYDAY=1WED'',',
'    enabled         => TRUE);',
'    ',
'exception',
'            when others then ',
'                l_errm := SQLERRM;',
'                insert into AP1_ERROR values (''Update_leave_details.employee_insert'',l_errm);',
'END;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43831819337371046325)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_personal_details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_errm varchar2(2000);',
'begin',
'    update AP1_EMPLOYEE_PROFILE ',
'    set ',
'    PERMANENT_ADDRESS = :P1_PERMENANT_ADDRESS,',
'    PERMANENT_PINCODE = :P1_PERMENANT_PINCODE,',
'    CURRENT_ADDRESS = :P1_CURRENT_ADDRESS,',
'    CURRENT_PINCODE = :P1_CURRENT_PINCODE,',
'    STATE = :P1_STATE,',
'    CITY = :P1_CITY',
'    where EMPLOYEE_ID = :P1_EMPLOYEE_ID;',
'    exception',
'        when others then ',
'            l_errm := SQLERRM;',
'            insert into AP1_ERROR values (''Update_personal_details.page1'',l_errm);',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(43831819277078046324)
);
wwv_flow_imp.component_end;
end;
/
