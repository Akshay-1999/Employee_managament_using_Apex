prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'promotions'
,p_alias=>'PROMOTIONS'
,p_page_mode=>'MODAL'
,p_step_title=>'promotions'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(42106489671190641379)
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'AKSHAY.PATIL@ESTUATE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230221044346'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41657102079788956502)
,p_plug_name=>'Promotions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(41631122246389264812)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41657102436733956506)
,p_button_sequence=>30
,p_button_name=>'Promote'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Promote'
,p_icon_css_classes=>'fa-chevron-circle-up'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41657102526810956507)
,p_button_sequence=>40
,p_button_name=>'Cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_image_alt=>'Cancel'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-circle-down'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(43831818990721046321)
,p_branch_name=>'go_to_page_employee'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(41657102436733956506)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41657102163099956503)
,p_name=>'P7_EMPLOYEE_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(41657102079788956502)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41657102257168956504)
,p_name=>'P7_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(41657102079788956502)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41657102370345956505)
,p_name=>'P7_ROLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41657102079788956502)
,p_prompt=>'Role'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select ROLE_NAME display, ROLE_ID return from AP1_ROLES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41657102702476956509)
,p_name=>'on_click_cancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(41657102526810956507)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41657102844126956510)
,p_event_id=>wwv_flow_imp.id(41657102702476956509)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'close_dilog'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41657103890847956520)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'promote_process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_errm varchar2(2000);',
'begin',
'    if :P7_ROLE = 3 then',
'        ap1_promotion_package.promote',
'        (',
'            p_employee_id=>:P7_EMPLOYEE_ID,',
'            p_role_id=>:P7_ROLE,',
'            p_EMPLOYEE_NAME=>:P7_NAME',
'        );',
'    elsif :P7_ROLE < 3 then',
'        ap1_promotion_package.demote',
'        (',
'            p_employee_id=>:P7_EMPLOYEE_ID,',
'            p_role_id=>:P7_ROLE',
'        );',
'    end if;',
'    exception',
'        when others then ',
'            l_errm := SQLERRM;',
'            insert into AP1_ERROR values (''promote_process.page7'',l_errm);',
'    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(41657102436733956506)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41657104366023956525)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close_dilog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_imp.component_end;
end;
/
