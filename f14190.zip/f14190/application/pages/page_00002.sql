prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Employee Details'
,p_alias=>'EMPLOYEE-DETAILS'
,p_step_title=>'Employee Details'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(42106489671190641379)
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'AKSHAY.PATIL@ESTUATE.COM'
,p_last_upd_yyyymmddhh24miss=>'20230217055621'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41256483148862957918)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41256484195747957928)
,p_plug_name=>'Work Details'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_plug_display_column=>1
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41256484478141957931)
,p_plug_name=>'Personal Details'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41256485126219957938)
,p_plug_name=>'Login Details'
,p_region_template_options=>'#DEFAULT#:t-Region--accent6:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41631188298670264842)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41256485598552957942)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(41256484195747957928)
,p_button_name=>'Promote'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Promote'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7:P7_EMPLOYEE_ID,P7_NAME,P7_ROLE:&P2_EMPLOYEE_ID.,&P2_FIRST_NAME.,&P2_ROLE.'
,p_button_condition=>'P2_REQUEST'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-circle-up'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41256485620800957943)
,p_button_sequence=>60
,p_button_name=>'Submit_button'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit '
,p_button_condition=>'P2_REQUEST'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41256485830465957945)
,p_button_sequence=>70
,p_button_name=>'Update'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update'
,p_button_condition=>'P2_REQUEST'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41256485980515957946)
,p_button_sequence=>80
,p_button_name=>'Delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete'
,p_button_condition=>'P2_REQUEST'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-remove'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41256485717200957944)
,p_button_sequence=>90
,p_button_name=>'Cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(41631261228519264879)
,p_button_image_alt=>'Cancel'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:2::'
,p_icon_css_classes=>'fa-x-axis'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(41657103123070956513)
,p_branch_name=>'Redirect_directory'
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(41256485620800957943)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(41657103297671956514)
,p_branch_name=>'Redirect_directory'
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:4::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(41256485830465957945)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256483273654957919)
,p_name=>'P2_EMPLOYEE_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_prompt=>'Employee Id'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P2_REQUEST'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256483398404957920)
,p_name=>'P2_REQUEST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256483433116957921)
,p_name=>'P2_FIRST_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_prompt=>'First Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256483546403957922)
,p_name=>'P2_LAST_NAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_prompt=>'Last Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256483641343957923)
,p_name=>'P2_EMAIL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256483793878957924)
,p_name=>'P2_CONTACT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_prompt=>'Contact'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256483856466957925)
,p_name=>'P2_GENDER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_prompt=>'Gender'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Male;Male,Female;Female'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256483964649957926)
,p_name=>'P2_JOINING_DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_prompt=>'Joining Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256484003677957927)
,p_name=>'P2_DATE_OF_BIRTH'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(41256483148862957918)
,p_prompt=>'Date Of Birth'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256484297237957929)
,p_name=>'P2_PROJECT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41256484195747957928)
,p_prompt=>'Project'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select project_name display,project_id return from ap1_project;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256484321652957930)
,p_name=>'P2_MANAGER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(41256484195747957928)
,p_prompt=>'Manager'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select EMPLOYEE_NAME display,EMPLOYEE_ID return from AP1_MANAGER;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256484551289957932)
,p_name=>'P2_PERMENANT_ADDRESS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41256484478141957931)
,p_prompt=>'Permenant Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256484687299957933)
,p_name=>'P2_PERMENANT_PINCODE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(41256484478141957931)
,p_prompt=>'Permenant Pincode'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256484789130957934)
,p_name=>'P2_CURRENT_ADDRESS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(41256484478141957931)
,p_prompt=>'Current Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256484804218957935)
,p_name=>'P2_CURRENT_PINCODE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(41256484478141957931)
,p_prompt=>'Current Pincode'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256484920282957936)
,p_name=>'P2_STATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(41256484478141957931)
,p_prompt=>'State'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select STATE_NAME display ,STATE_NAME return from ap1_state',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256485056644957937)
,p_name=>'P2_CITY'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(41256484478141957931)
,p_prompt=>'City'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select CITY_NAME display,CITY_NAME return from ap1_city where STATE_NAME = :P2_STATE'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P2_STATE'
,p_ajax_items_to_submit=>'P2_CITY'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256485284834957939)
,p_name=>'P2_PASSWORD'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41256485126219957938)
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_display_when=>'P2_REQUEST'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256485351988957940)
,p_name=>'P2_CONFIRM_PASSWORD'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(41256485126219957938)
,p_prompt=>'Confirm Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_display_when=>'P2_REQUEST'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41256486392053957950)
,p_name=>'P2_STATUS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(41256485126219957938)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Working;Working,Resigned ;Resigned '
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P2_REQUEST'
,p_display_when2=>'UPDATE'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41657101941126956501)
,p_name=>'P2_ROLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(41256484195747957928)
,p_prompt=>'Role'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select ROLE_NAME display,ROLE_ID return from AP1_ROLES'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(41631258638229264878)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(41256486009481957947)
,p_validation_name=>'Passworld_validation'
,p_validation_sequence=>10
,p_validation=>':P2_PASSWORD = :P2_CONFIRM_PASSWORD'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'password does not match!!'
,p_validation_condition=>'P2_REQUEST'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_imp.id(41256485351988957940)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(42599890405483978208)
,p_validation_name=>'Email_validation'
,p_validation_sequence=>20
,p_validation=>'P2_EMAIL'
,p_validation2=>' ^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Not a valid email'
,p_validation_condition=>'P2_EMAIL'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_imp.id(41256483641343957923)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(46426136642518337832)
,p_validation_name=>'Password_validation'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF 8 <= LENGTH(:P2_PASSWORD) AND  LENGTH(:P2_PASSWORD) <= 15  THEN',
'    IF REGEXP_LIKE(:P2_PASSWORD, ''^.*[0-9]'') THEN',
' IF REGEXP_LIKE(:P2_PASSWORD, ''^.*[a-z]'', ''c'') THEN',
' IF REGEXP_LIKE(:P2_PASSWORD, ''^.*[A-Z]'', ''c'') THEN',
' IF REGEXP_LIKE(:P2_PASSWORD, ''^.*[!@#$%^&*()_]'', ''c'') THEN',
' RETURN '''';',
' ELSE',
'    RETURN ''Password has not one special character'';',
' END IF;',
' ELSE',
'    RETURN ''Password has not one UpperCase'';',
' END IF;   ',
' ELSE',
'    RETURN ''Password has not one LowerCase'';',
' END IF;',
' ELSE',
'    RETURN ''Password has not a numeric value'';',
' END IF; ',
'ELSE',
'RETURN ''Password Length Must be min 8 char and max 15 char',
'and your password length is''||'' ''||LENGTH(:P2_PASSWORD);',
'END IF;',
'',
'END;'))
,p_validation_type=>'PLSQL_ERROR'
,p_error_message=>'password is not strong enough!!'
,p_validation_condition_type=>'NEVER'
,p_associated_item=>wwv_flow_imp.id(41256485284834957939)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41657103994646956521)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'pre_populating_update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select ',
'        FIRST_NAME,',
'        LAST_NAME,',
'        EMAIL,',
'        CONTACT,',
'        GENDER,',
'        JOINING_DATE,',
'        DATE_OF_BIRTH',
'    into',
'        :P2_FIRST_NAME,',
'        :P2_LAST_NAME,',
'        :P2_EMAIL,',
'        :P2_CONTACT,',
'        :P2_GENDER,',
'        :P2_JOINING_DATE,',
'        :P2_DATE_OF_BIRTH',
'    from ap1_employee where employee_id =:P2_EMPLOYEE_ID ;',
'    select ',
'        PERMANENT_ADDRESS,',
'        PERMANENT_PINCODE,',
'        CURRENT_ADDRESS,',
'        CURRENT_PINCODE,',
'        STATE,',
'        CITY',
'    into',
'        :P2_PERMENANT_ADDRESS,',
'        :P2_PERMENANT_PINCODE,',
'        :P2_CURRENT_ADDRESS,',
'        :P2_CURRENT_PINCODE,',
'        :P2_STATE,',
'        :P2_CITY',
'    from AP1_EMPLOYEE_PROFILE where employee_id = :P2_EMPLOYEE_ID;',
'    select ',
'        PROJECT_ID,',
'        MANAGER_ID',
'    into',
'        :P2_PROJECT,',
'        :P2_MANAGER',
'    from AP1_EMP_PRO_MAN where employee_id = :P2_EMPLOYEE_ID;',
'    select',
'        ROLE_ID',
'    into',
'        :P2_ROLE',
'    from AP1_EMP_ROLE where employee_id = :P2_EMPLOYEE_ID;',
'    select',
'        STATUS',
'    into',
'        :P2_STATUS',
'    from AP1_LOGIN_DETAILS where employee_id = :P2_EMPLOYEE_ID;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P2_REQUEST'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'UPDATE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41657103674305956518)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'insert_process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    ap1_application_package.employee_insert',
'    (',
'        p_FIRST_NAME=>:P2_FIRST_NAME,',
'        p_LAST_NAME=>:P2_LAST_NAME,',
'        p_EMAIL=>:P2_EMAIL,',
'        p_CONTACT=>:P2_CONTACT,',
'        p_GENDER=>:P2_GENDER,',
'        p_JOINING_DATE=>:P2_JOINING_DATE,',
'        p_DATE_OF_BIRTH=>:P2_DATE_OF_BIRTH,',
'        --ap1_employee_profile--',
'        p_PERMANENT_ADDRESS=>:P2_PERMENANT_ADDRESS,',
'        p_PERMANENT_PINCODE=>:P2_PERMENANT_PINCODE,',
'        p_CURRENT_ADDRESS=>:P2_CURRENT_ADDRESS,',
'        p_CURRENT_PINCODE=>:P2_CURRENT_PINCODE,',
'        p_STATE=>:P2_STATE,',
'        p_CITY=>:P2_CITY,',
'        --ap1_EMP_PRO_MAN--',
'        p_PROJECT_ID=>:P2_PROJECT,',
'        p_MANAGER_ID=>:P2_MANAGER,',
'        --ap1_emp_role--',
'        p_role_id=>:P2_ROLE,',
'        --ap1_login_details--',
'        p_PASSWORD =>:P2_CONFIRM_PASSWORD',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(41256485620800957943)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41657104012154956522)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update_Process'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    ap1_application_package.employee_update',
'    (',
'        p_EMPLOYEE_ID=>:P2_EMPLOYEE_ID,',
'        p_FIRST_NAME=>:P2_FIRST_NAME,',
'        p_LAST_NAME=>:P2_LAST_NAME,',
'        p_EMAIL=>:P2_EMAIL,',
'        p_CONTACT=>:P2_CONTACT,',
'        p_GENDER=>:P2_GENDER,',
'        p_JOINING_DATE=>:P2_JOINING_DATE,',
'        p_DATE_OF_BIRTH=>:P2_DATE_OF_BIRTH,',
'        --ap1_employee_profile--',
'        p_PERMANENT_ADDRESS=>:P2_PERMENANT_ADDRESS,',
'        p_PERMANENT_PINCODE=>:P2_PERMENANT_PINCODE,',
'        p_CURRENT_ADDRESS=>:P2_CURRENT_ADDRESS,',
'        p_CURRENT_PINCODE=>:P2_CURRENT_PINCODE,',
'        p_STATE=>:P2_STATE,',
'        p_CITY=>:P2_CITY,',
'        --ap1_EMP_PRO_MAN--',
'        p_PROJECT_ID=>:P2_PROJECT,',
'        p_MANAGER_ID=>:P2_MANAGER,',
'        --ap1_login_details--',
'        p_STATUS=>:P2_STATUS',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(41256485830465957945)
);
wwv_flow_imp.component_end;
end;
/
