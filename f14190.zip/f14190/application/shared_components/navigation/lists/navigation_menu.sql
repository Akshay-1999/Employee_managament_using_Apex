prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(41631085924899264793)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(41631297033530264904)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(41634854862161400707)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Directory'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_status number := :G_USER_ROLE;',
'begin',
' if l_status = 1 then',
'  return true;',
' else',
'  return false;',
' end if;',
'end;',
''))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(42120785761500919291)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Submission',
''))
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-alarm-clock'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(42120802425590921821)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Review Time sheet'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-check-o'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_status number := :G_USER_ROLE;',
'begin',
' if l_status = 3 then',
'  return true;',
' else',
'  return false;',
' end if;',
'end;',
''))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(42120785761500919291)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(43738226455341701726)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Day Entry'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-arrow-up'
,p_parent_list_item_id=>wwv_flow_imp.id(42120785761500919291)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'9'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(54604971580150458018)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Applie Leave'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-check-o'
,p_parent_list_item_id=>wwv_flow_imp.id(42120785761500919291)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(57213992130328843742)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Week Entry'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.:START_STOP_DATE:&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-clock'
,p_parent_list_item_id=>wwv_flow_imp.id(42120785761500919291)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55987401999214043876)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Help',
''))
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-info-circle'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'17'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(56093081468309586733)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Ticket Review'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_parent_list_item_id=>wwv_flow_imp.id(55987401999214043876)
,p_security_scheme=>wwv_flow_imp.id(56097696887441158260)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(56493586142199509734)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Assets',
''))
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-4k'
,p_security_scheme=>wwv_flow_imp.id(56533551876466296511)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'15'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(56504968832392332484)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Assets Directory'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-book-o'
,p_parent_list_item_id=>wwv_flow_imp.id(56493586142199509734)
,p_security_scheme=>wwv_flow_imp.id(56533551876466296511)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20'
);
wwv_flow_imp.component_end;
end;
/
