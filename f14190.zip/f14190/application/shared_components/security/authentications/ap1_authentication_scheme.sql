prompt --application/shared_components/security/authentications/ap1_authentication_scheme
begin
--   Manifest
--     AUTHENTICATION: Ap1_Authentication Scheme
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(41790617728662810464)
,p_name=>'Ap1_Authentication Scheme'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'user_aut'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'FUNCTION user_aut    ',
'(',
'     p_username IN VARCHAR2, --User_Name',
'     p_password IN VARCHAR2 -- Password    ',
')',
' RETURN BOOLEAN',
'AS',
' l_value VARCHAR2 (1);',
' l_status varchar2(100);',
'BEGIN',
' -- Validate whether the user exits or not',
'    select r.ROLE_id,''Y'',l.employee_id,l.STATUS ',
'    into',
'    :G_USER_ROLE,l_value,:G_USER_ID,l_status',
'    from ',
'     AP1_EMP_ROLE r',
'    join ',
'    AP1_LOGIN_DETAILS l on l.employee_id = r.employee_id',
'    WHERE upper(USER_NAME) = UPPER (p_username) AND PASSWORD = p_password;',
'    if l_status = ''Working'' then',
'        RETURN TRUE;',
'    else',
'         RETURN FALSE;',
'    end if;',
'EXCEPTION',
'    WHEN NO_DATA_FOUND',
'    THEN',
'        RETURN FALSE;',
'END user_aut;'))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
