prompt --application/shared_components/security/authorizations/manager_rights
begin
--   Manifest
--     SECURITY SCHEME: manager_rights
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>56869868664365987711
,p_default_application_id=>14190
,p_default_id_offset=>0
,p_default_owner=>'WKSP_STANFORDESTUATE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(42121518936113941514)
,p_name=>'manager_rights'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_status number := :G_USER_ROLE;',
'begin',
' if l_status = 3 then',
'  return true;',
' else',
'  return false;',
' end if;',
'end;'))
,p_error_message=>' access denied!!'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
,p_comments=>'access denied '
);
wwv_flow_imp.component_end;
end;
/
